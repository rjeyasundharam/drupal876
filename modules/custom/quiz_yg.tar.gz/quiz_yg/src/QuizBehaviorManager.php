<?php

namespace Drupal\quiz_yg;

use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Plugin\DefaultPluginManager;

/**
 * Plugin type manager for quiz_yg type behavior plugins.
 *
 * @ingroup quiz_yg_behavior
 */
class QuizBehaviorManager extends DefaultPluginManager {

  /**
   * Constructs a QuizBehaviorManager object.
   *
   * @param \Traversable $namespaces
   *   An object that implements \Traversable which contains the root paths
   *   keyed by the corresponding namespace to look for plugin implementations.
   * @param \Drupal\Core\Cache\CacheBackendInterface $cache_backend
   *   Cache backend instance to use.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $module_handler
   *   The module handler.
   */
  public function __construct(\Traversable $namespaces, CacheBackendInterface $cache_backend, ModuleHandlerInterface $module_handler) {
    parent::__construct('Plugin/quiz_yg/Behavior', $namespaces, $module_handler, 'Drupal\quiz_yg\QuizBehaviorInterface', 'Drupal\quiz_yg\Annotation\QuizBehavior');
    $this->setCacheBackend($cache_backend, 'quiz_yg_behavior_plugins');
    $this->alterInfo('quiz_yg_behavior_info');
  }

  /**
   * {@inheritdoc}
   */
  public function getDefinitions() {
    $definitions =  parent::getDefinitions();
    uasort($definitions, 'Drupal\Component\Utility\SortArray::sortByWeightElement');
    return $definitions;
  }

  /**
   * Gets the applicable behavior plugins.
   *
   * Loop over the plugin definitions, check the applicability of each one of
   * them and return the array of the applicable plugins.
   *
   * @return array
   *   The applicable behavior plugins.
   */
  public function getApplicableDefinitions($quiz_yg_type) {
    $definitions = $this->getDefinitions();
    $applicable_plugins = [];
    foreach ($definitions as $key => $definition) {
      if ($definition['class']::isApplicable($quiz_yg_type)) {
        $applicable_plugins[$key] = $definition;
      }
    }
    return $applicable_plugins;
  }

}
