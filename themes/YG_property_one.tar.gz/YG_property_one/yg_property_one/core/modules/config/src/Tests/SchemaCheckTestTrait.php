<?php

namespace Drupal\config\Tests;

/**
 * Provides a class for checking configuration schema.
 *
 * @deprecated as of 8.3.x, will be removed in before Drupal 9.0.0.
 */
trait SchemaCheckTestTrait {

  use \Drupal\Tests\SchemaCheckTestTrait;

}
