<?php

namespace Drupal\quickedit_test;

/**
 * @deprecated in Drupal 8.4.x and will be removed before Drupal 9.0.0.
 */
class MockEditEntityFieldAccessCheck extends MockQuickEditEntityFieldAccessCheck {

}
